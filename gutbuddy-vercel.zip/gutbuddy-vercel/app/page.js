"use client";
import GutBuddyApp from "./GutBuddy";

export default function Home() {
  return <GutBuddyApp />;
}
